<template>
	<div>
		{{msg}}
	</div>
</template>

<script>
export default {
	 name : 'Home',
	 data : () => ({
		 msg : 'home page'
	 })
}
</script>

<style>

</style>
