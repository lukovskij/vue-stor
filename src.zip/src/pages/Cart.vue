<template>
	<div>
		{{msg}}
	</div>
</template>

<script>
export default {
	 name : 'Cart',
	 data : () => ({
		 msg : 'Cart'
	 })
}
</script>

<style>

</style>