<template>
	<div>
		{{msg}}
	</div>
</template>

<script>
export default {
	 name : 'Product',
	 data : () => ({
		 msg : 'Products page'
	 })
}
</script>